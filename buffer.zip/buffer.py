from qgis.core import QgsProject
names = [layer.name() for layer in QgsProject.instance().mapLayers().values()]
print(names)
print(type(names))
#layerName = names
for layerName in names:
    outFile = '/home/abdul/projects/buffer_calculator/buffer.shp'
    bufDist = -0.010
    layers = QgsProject.instance().mapLayersByName(layerName)
    layer = layers[0]
    fields = layer.fields()
    feats = layer.getFeatures()

    writer = QgsVectorFileWriter(outFile, 'UTF-8', fields, \
    QgsWkbTypes.Polygon, layer.sourceCrs(), 'ESRI Shapefile')

    for feat in feats:
        geom = feat.geometry()
        buffer = geom.buffer(bufDist, 5)
        feat.setGeometry(buffer)
        writer.addFeature(feat)
    print('done')
    iface.addVectorLayer(outFile, '', 'ogr')
    del(writer)